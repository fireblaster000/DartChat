"""
Unit Tests for Certificate Generation Module
Tests certificate creation, validation, and file output
"""
import unittest
import os
import shutil
import tempfile
from datetime import datetime, timedelta
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import sys

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from generate_certificates import generate_certificates


class TestCertificateGeneration(unittest.TestCase):
    """Test certificate generation functionality"""
    
    def setUp(self):
        """Set up test environment"""
        self.test_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()
        os.chdir(self.test_dir)
        
    def tearDown(self):
        """Clean up test environment"""
        os.chdir(self.original_cwd)
        shutil.rmtree(self.test_dir)
    
    def test_certificates_directory_created(self):
        """Test that certs directory is created"""
        generate_certificates()
        self.assertTrue(os.path.exists('certs'))
        self.assertTrue(os.path.isdir('certs'))
    
    def test_private_key_generated(self):
        """Test that private key file is created"""
        generate_certificates()
        key_path = 'certs/server.key'
        
        self.assertTrue(os.path.exists(key_path))
        
        # Verify it's a valid PEM private key
        with open(key_path, 'rb') as f:
            key_data = f.read()
            self.assertIn(b'BEGIN RSA PRIVATE KEY', key_data)
    
    def test_certificate_generated(self):
        """Test that certificate file is created"""
        generate_certificates()
        cert_path = 'certs/server.crt'
        
        self.assertTrue(os.path.exists(cert_path))
        
        # Verify it's a valid PEM certificate
        with open(cert_path, 'rb') as f:
            cert_data = f.read()
            self.assertIn(b'BEGIN CERTIFICATE', cert_data)
    
    def test_certificate_validity_period(self):
        """Test that certificate has correct validity period"""
        generate_certificates()
        
        with open('certs/server.crt', 'rb') as f:
            cert_data = f.read()
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
        
        # Check validity is approximately 365 days
        validity_period = cert.not_valid_after - cert.not_valid_before
        self.assertAlmostEqual(validity_period.days, 365, delta=1)
    
    def test_certificate_subject_fields(self):
        """Test that certificate contains correct subject fields"""
        generate_certificates()
        
        with open('certs/server.crt', 'rb') as f:
            cert_data = f.read()
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
        
        subject = cert.subject
        subject_dict = {attr.oid._name: attr.value for attr in subject}
        
        self.assertEqual(subject_dict.get('countryName'), 'US')
        self.assertEqual(subject_dict.get('commonName'), 'localhost')
        self.assertEqual(subject_dict.get('organizationName'), 'Secure Chat')
    
    def test_certificate_has_san_extension(self):
        """Test that certificate includes Subject Alternative Name"""
        generate_certificates()
        
        with open('certs/server.crt', 'rb') as f:
            cert_data = f.read()
            cert = x509.load_pem_x509_certificate(cert_data, default_backend())
        
        # Check for SAN extension
        try:
            san_ext = cert.extensions.get_extension_for_oid(
                x509.oid.ExtensionOID.SUBJECT_ALTERNATIVE_NAME
            )
            self.assertIsNotNone(san_ext)
        except x509.ExtensionNotFound:
            self.fail("Certificate missing Subject Alternative Name extension")
    
    def test_key_size(self):
        """Test that private key has correct size"""
        from cryptography.hazmat.primitives.asymmetric import rsa
        
        generate_certificates()
        
        with open('certs/server.key', 'rb') as f:
            key_data = f.read()
            private_key = serialization.load_pem_private_key(
                key_data, password=None, backend=default_backend()
            )
        
        self.assertIsInstance(private_key, rsa.RSAPrivateKey)
        self.assertEqual(private_key.key_size, 2048)
    
    def test_multiple_generation_overwrites(self):
        """Test that generating certificates multiple times overwrites existing ones"""
        generate_certificates()
        
        # Modify certificate file
        with open('certs/server.crt', 'a') as f:
            f.write("\n# Modified")
        
        # Generate again
        generate_certificates()
        
        # Check that modification is gone
        with open('certs/server.crt', 'r') as f:
            content = f.read()
            self.assertNotIn("# Modified", content)


if __name__ == '__main__':
    unittest.main()
