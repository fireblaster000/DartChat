# DartChat Test Suite

Comprehensive testing for the secure chat application covering unit tests, integration tests, and end-to-end scenarios.

## Test Structure

### Unit Tests

- **test_generate_certificates.py** - Certificate generation and validation
- **test_voice_call.py** - Voice call functionality and audio streaming
- **test_chat_client.py** - Client message handling and commands
- **test_chat_server.py** - Server logic and room management

### Integration Tests

- **test_integration.py** - Component interactions and complete workflows
  - Client-server communication
  - Room management workflows
  - File transfer flows
  - Voice call integration

### Edge Case Tests

- **test_edge_cases.py** - Error handling and boundary conditions
  - Invalid inputs
  - Concurrent access
  - Network failures
  - Resource limits

## Running Tests

### Run All Tests
\`\`\`bash
python tests/run_all_tests.py
\`\`\`

### Run Specific Test File
\`\`\`bash
python -m unittest tests/test_chat_server.py
\`\`\`

### Run Specific Test Class
\`\`\`bash
python -m unittest tests.test_chat_server.TestChatRoom
\`\`\`

### Run Specific Test Method
\`\`\`bash
python -m unittest tests.test_chat_server.TestChatRoom.test_add_member
\`\`\`

### Run with Verbose Output
\`\`\`bash
python -m unittest discover -v tests/
\`\`\`

## Test Coverage

### Core Functionality
- ✅ Certificate generation and TLS setup
- ✅ User authentication and validation
- ✅ Message broadcasting and private messaging
- ✅ Room creation and management
- ✅ File transfer (send, receive, broadcast)
- ✅ Voice call setup and audio streaming

### User Interactions
- ✅ Connection handshake
- ✅ Command parsing (/pm, /join, /create, etc.)
- ✅ File operations (send, accept, reject, view)
- ✅ Voice call lifecycle (start, mute, end)

### Data Processing
- ✅ Message serialization/deserialization
- ✅ File encoding/decoding (base64)
- ✅ Username validation
- ✅ Room membership tracking

### Error Handling
- ✅ Invalid usernames
- ✅ Empty/whitespace messages
- ✅ Non-existent users/rooms
- ✅ File size limits
- ✅ Cross-room restrictions
- ✅ Concurrent access

## Dependencies

Required for running tests:
- unittest (Python standard library)
- cryptography (for certificate tests)
- pyaudio (mocked in tests, required for actual application)

## CI/CD Integration

Add to your CI pipeline:
\`\`\`yaml
test:
  script:
    - pip install cryptography pyaudio
    - python tests/run_all_tests.py
\`\`\`

## Test Maintenance

When adding new features:
1. Add unit tests for individual components
2. Add integration tests for component interactions
3. Add edge case tests for error conditions
4. Update this README with new test coverage

## Notes

- Tests use mocking for external dependencies (SSL, audio, sockets)
- Integration tests simulate component interactions without actual network connections
- Some tests require temporary directories which are automatically cleaned up
- Voice call tests mock PyAudio to avoid audio hardware dependencies
