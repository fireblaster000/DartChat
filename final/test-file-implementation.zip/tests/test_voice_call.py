"""
Unit Tests for Voice Call Module
Tests audio streaming, mute functionality, and connection handling
"""
import unittest
import socket
import threading
import time
from unittest.mock import Mock, patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from voice_call import VoiceCall
from audio_test import AudioTester


class TestVoiceCall(unittest.TestCase):
    """Test voice call functionality"""
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_voice_call_initialization(self, mock_pyaudio):
        """Test VoiceCall object initialization"""
        call = VoiceCall('127.0.0.1', 5001, 5000)
        
        self.assertEqual(call.peer_ip, '127.0.0.1')
        self.assertEqual(call.peer_port, 5001)
        self.assertEqual(call.local_port, 5000)
        self.assertFalse(call.is_active)
        self.assertFalse(call.is_muted)
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_voice_call_start_success(self, mock_pyaudio):
        """Test successful voice call start"""
        # Mock audio streams
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        mock_audio.open.return_value = MagicMock()
        
        call = VoiceCall('127.0.0.1', 5001, 5000)
        result = call.start()
        
        self.assertTrue(result)
        self.assertTrue(call.is_active)
        self.assertIsNotNone(call.input_stream)
        self.assertIsNotNone(call.output_stream)
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_toggle_mute(self, mock_pyaudio):
        """Test microphone mute toggle"""
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        mock_audio.open.return_value = MagicMock()
        
        call = VoiceCall('127.0.0.1', 5001, 5000)
        call.start()
        
        # Test toggle on
        self.assertFalse(call.is_muted)
        is_muted = call.toggle_mute()
        self.assertTrue(is_muted)
        self.assertTrue(call.is_muted)
        
        # Test toggle off
        is_muted = call.toggle_mute()
        self.assertFalse(is_muted)
        self.assertFalse(call.is_muted)
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_voice_call_stop(self, mock_pyaudio):
        """Test voice call cleanup"""
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        mock_stream = MagicMock()
        mock_audio.open.return_value = mock_stream
        
        call = VoiceCall('127.0.0.1', 5001, 5000)
        call.start()
        time.sleep(0.1)  # Let threads start
        
        call.stop()
        
        self.assertFalse(call.is_active)
        mock_stream.stop_stream.assert_called()
        mock_stream.close.assert_called()
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_cannot_start_active_call(self, mock_pyaudio):
        """Test that active call cannot be restarted"""
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        mock_audio.open.return_value = MagicMock()
        
        call = VoiceCall('127.0.0.1', 5001, 5000)
        call.start()
        
        # Try to start again
        result = call.start()
        self.assertFalse(result)
    
    def test_audio_packet_structure(self):
        """Test audio packet includes sequence number"""
        import struct
        
        # Simulate packet structure
        sequence = 42
        audio_data = b'\x00\x01\x02\x03'
        packet = struct.pack('I', sequence) + audio_data
        
        # Unpack
        unpacked_seq = struct.unpack('I', packet[:4])[0]
        unpacked_audio = packet[4:]
        
        self.assertEqual(unpacked_seq, sequence)
        self.assertEqual(unpacked_audio, audio_data)


class TestAudioTester(unittest.TestCase):
    """Test audio testing module"""
    
    @patch('audio_test.pyaudio.PyAudio')
    def test_audio_tester_initialization(self, mock_pyaudio):
        """Test AudioTester initialization"""
        tester = AudioTester()
        
        self.assertEqual(tester.CHUNK, 1024)
        self.assertEqual(tester.CHANNELS, 1)
        self.assertEqual(tester.RATE, 44100)
    
    @patch('audio_test.pyaudio.PyAudio')
    def test_list_devices(self, mock_pyaudio):
        """Test audio device listing"""
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        
        # Mock device info
        mock_audio.get_host_api_info_by_index.return_value = {'deviceCount': 2}
        mock_audio.get_device_info_by_host_api_device_index.return_value = {
            'name': 'Test Device',
            'maxInputChannels': 2,
            'maxOutputChannels': 2,
            'defaultSampleRate': 44100
        }
        
        tester = AudioTester()
        
        # Should not raise exception
        try:
            tester.list_devices()
        except Exception as e:
            self.fail(f"list_devices raised exception: {e}")


if __name__ == '__main__':
    unittest.main()
