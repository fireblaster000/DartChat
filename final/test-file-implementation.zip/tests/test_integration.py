"""
Integration Tests for DartChat Application
Tests complete workflows and component interactions
"""
import unittest
import socket
import ssl
import json
import threading
import time
import tempfile
import shutil
import os
from unittest.mock import Mock, patch, MagicMock
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from chat_server import SecureChatServer, ChatRoom
from chat_client import SecureChatClient
from voice_call import VoiceCall


class TestClientServerIntegration(unittest.TestCase):
    """Test client-server communication integration"""
    
    @patch('chat_server.ssl.SSLContext')
    @patch('chat_client.ssl.SSLContext')
    def test_connection_handshake(self, mock_client_ssl, mock_server_ssl):
        """Test complete connection handshake between client and server"""
        from chat_server import SecureChatServer
        from chat_client import SecureChatClient
        
        # This would require actual socket connections
        # For now, test the flow logic
        
        server = SecureChatServer()
        client = SecureChatClient()
        
        # Verify initial states
        self.assertFalse(server.running)
        self.assertFalse(client.connected)
    
    def test_message_flow_serialization(self):
        """Test message serialization/deserialization flow"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        # Create test message
        original_msg = {
            'type': 'message',
            'username': 'testuser',
            'content': 'Hello',
            'timestamp': '12:00:00'
        }
        
        # Serialize
        data = json.dumps(original_msg).encode('utf-8')
        packet = len(data).to_bytes(4, byteorder='big') + data
        
        # Deserialize
        msg_len = int.from_bytes(packet[:4], 'big')
        received_data = packet[4:4+msg_len]
        received_msg = json.loads(received_data.decode('utf-8'))
        
        self.assertEqual(original_msg, received_msg)
    
    def test_room_workflow(self):
        """Test complete room creation and joining workflow"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        # Mock clients
        client1 = MagicMock()
        client2 = MagicMock()
        
        # Add clients
        server.clients[client1] = {
            'username': 'user1',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[client2] = {
            'username': 'user2',
            'room': 'general',
            'address': ('127.0.0.1', 12346)
        }
        server.username_map['user1'] = client1
        server.username_map['user2'] = client2
        server.rooms['general'].add_member('user1')
        server.rooms['general'].add_member('user2')
        
        # User1 creates new room
        server.process_message(client1, {
            'type': 'create_room',
            'room_name': 'private'
        })
        
        self.assertIn('private', server.rooms)
        
        # User1 joins new room
        server.process_message(client1, {
            'type': 'join_room',
            'room_name': 'private'
        })
        
        self.assertEqual(server.clients[client1]['room'], 'private')
        self.assertIn('user1', server.rooms['private'].members)
        self.assertNotIn('user1', server.rooms['general'].members)
    
    def test_file_transfer_workflow(self):
        """Test complete file transfer workflow"""
        from chat_server import SecureChatServer
        import base64
        
        server = SecureChatServer()
        
        # Mock sender and receiver
        sender = MagicMock()
        receiver = MagicMock()
        
        server.clients[sender] = {
            'username': 'sender',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[receiver] = {
            'username': 'receiver',
            'room': 'general',
            'address': ('127.0.0.1', 12346)
        }
        server.username_map['sender'] = sender
        server.username_map['receiver'] = receiver
        server.rooms['general'].add_member('sender')
        server.rooms['general'].add_member('receiver')
        
        # Sender initiates file transfer
        file_data = base64.b64encode(b'Test file content').decode('utf-8')
        
        server.process_message(sender, {
            'type': 'file_send',
            'targets': ['receiver'],
            'filename': 'test.txt',
            'filesize': 17,
            'data': file_data
        })
        
        # Verify file offer created
        self.assertTrue(len(server.pending_files) > 0)
        
        # Get file ID from the offer
        file_id = list(server.pending_files.keys())[0]
        
        # Receiver accepts file
        server.process_message(receiver, {
            'type': 'file_accept',
            'file_id': file_id
        })
        
        # Verify file transfer completed
        self.assertTrue(receiver.sendall.called)
    
    def test_broadcast_message_workflow(self):
        """Test message broadcasting to room members"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        # Create multiple clients in same room
        clients = []
        for i in range(3):
            client = MagicMock()
            clients.append(client)
            server.clients[client] = {
                'username': f'user{i}',
                'room': 'general',
                'address': ('127.0.0.1', 12345 + i)
            }
            server.username_map[f'user{i}'] = client
            server.rooms['general'].add_member(f'user{i}')
        
        # Send message from first user
        server.process_message(clients[0], {
            'type': 'message',
            'content': 'Hello everyone'
        })
        
        # Verify all other clients received message (not sender)
        self.assertTrue(clients[1].sendall.called)
        self.assertTrue(clients[2].sendall.called)


class TestVoiceCallIntegration(unittest.TestCase):
    """Test voice call integration with server"""
    
    def test_call_request_workflow(self):
        """Test complete voice call request workflow"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        # Mock caller and callee
        caller = MagicMock()
        callee = MagicMock()
        
        server.clients[caller] = {
            'username': 'caller',
            'room': 'general',
            'address': ('192.168.1.10', 12345)
        }
        server.clients[callee] = {
            'username': 'callee',
            'room': 'general',
            'address': ('192.168.1.11', 12346)
        }
        server.username_map['caller'] = caller
        server.username_map['callee'] = callee
        server.rooms['general'].add_member('caller')
        server.rooms['general'].add_member('callee')
        
        # Caller initiates call
        server.process_message(caller, {
            'type': 'call_request',
            'target': 'callee',
            'voice_port': 5000
        })
        
        # Verify call offer sent to callee
        self.assertTrue(callee.sendall.called)
    
    @patch('voice_call.pyaudio.PyAudio')
    def test_voice_call_lifecycle(self, mock_pyaudio):
        """Test complete voice call lifecycle"""
        from voice_call import VoiceCall
        
        mock_audio = MagicMock()
        mock_pyaudio.return_value = mock_audio
        mock_audio.open.return_value = MagicMock()
        
        # Start call
        call = VoiceCall('127.0.0.1', 5001, 5000)
        result = call.start()
        self.assertTrue(result)
        self.assertTrue(call.is_active)
        
        # Mute
        call.toggle_mute()
        self.assertTrue(call.is_muted)
        
        # Unmute
        call.toggle_mute()
        self.assertFalse(call.is_muted)
        
        # End call
        call.stop()
        self.assertFalse(call.is_active)


class TestEndToEndScenarios(unittest.TestCase):
    """End-to-end test scenarios simulating real user behavior"""
    
    def test_user_joins_chats_and_leaves(self):
        """Test complete user session from join to leave"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        client = MagicMock()
        
        # User connects
        username = 'testuser'
        server.clients[client] = {
            'username': username,
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.username_map[username] = client
        server.rooms['general'].add_member(username)
        
        # User sends messages
        for i in range(3):
            server.process_message(client, {
                'type': 'message',
                'content': f'Message {i}'
            })
        
        self.assertEqual(len(server.rooms['general'].message_history), 3)
        
        # User disconnects
        server.disconnect_client(client, username)
        
        self.assertNotIn(username, server.username_map)
        self.assertNotIn(username, server.rooms['general'].members)
    
    def test_multi_user_chat_scenario(self):
        """Test multiple users chatting in different rooms"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        # Create users
        users = []
        for i in range(5):
            client = MagicMock()
            username = f'user{i}'
            users.append((client, username))
            
            server.clients[client] = {
                'username': username,
                'room': 'general',
                'address': ('127.0.0.1', 12345 + i)
            }
            server.username_map[username] = client
            server.rooms['general'].add_member(username)
        
        # Create second room
        server.rooms['vip'] = server.rooms['general'].__class__('vip')
        
        # Move some users to VIP room
        for client, username in users[3:]:
            server.process_message(client, {
                'type': 'join_room',
                'room_name': 'vip'
            })
        
        # Verify room membership
        self.assertEqual(len(server.rooms['general'].members), 3)
        self.assertEqual(len(server.rooms['vip'].members), 2)
        
        # Send messages in both rooms
        server.process_message(users[0][0], {
            'type': 'message',
            'content': 'Hello general'
        })
        
        server.process_message(users[3][0], {
            'type': 'message',
            'content': 'Hello VIP'
        })
        
        self.assertEqual(len(server.rooms['general'].message_history), 1)
        self.assertEqual(len(server.rooms['vip'].message_history), 1)
    
    def test_private_messaging_scenario(self):
        """Test private messaging between users"""
        from chat_server import SecureChatServer
        
        server = SecureChatServer()
        
        user1 = MagicMock()
        user2 = MagicMock()
        
        server.clients[user1] = {
            'username': 'alice',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[user2] = {
            'username': 'bob',
            'room': 'general',
            'address': ('127.0.0.1', 12346)
        }
        server.username_map['alice'] = user1
        server.username_map['bob'] = user2
        
        # Alice sends PM to Bob
        server.process_message(user1, {
            'type': 'private_message',
            'target': 'bob',
            'content': 'Hi Bob, private message'
        })
        
        # Verify Bob received it
        self.assertTrue(user2.sendall.called)
        
        # Verify Alice got confirmation
        call_count_before = user1.sendall.call_count
        self.assertGreater(call_count_before, 0)


if __name__ == '__main__':
    unittest.main()
