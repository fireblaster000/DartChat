"""
Unit Tests for Chat Server
Tests server initialization, client handling, and room management
"""
import unittest
import socket
import json
import threading
import time
from unittest.mock import Mock, patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from chat_server import ChatRoom, SecureChatServer


class TestChatRoom(unittest.TestCase):
    """Test ChatRoom functionality"""
    
    def test_room_initialization(self):
        """Test room object creation"""
        room = ChatRoom('test_room')
        
        self.assertEqual(room.name, 'test_room')
        self.assertEqual(len(room.members), 0)
        self.assertEqual(len(room.message_history), 0)
    
    def test_add_member(self):
        """Test adding members to room"""
        room = ChatRoom('test_room')
        room.add_member('user1')
        room.add_member('user2')
        
        self.assertIn('user1', room.members)
        self.assertIn('user2', room.members)
        self.assertEqual(len(room.members), 2)
    
    def test_remove_member(self):
        """Test removing members from room"""
        room = ChatRoom('test_room')
        room.add_member('user1')
        room.add_member('user2')
        room.remove_member('user1')
        
        self.assertNotIn('user1', room.members)
        self.assertIn('user2', room.members)
    
    def test_add_duplicate_member(self):
        """Test that adding same member twice doesn't create duplicates"""
        room = ChatRoom('test_room')
        room.add_member('user1')
        room.add_member('user1')
        
        self.assertEqual(len(room.members), 1)
    
    def test_remove_nonexistent_member(self):
        """Test removing member that doesn't exist doesn't raise error"""
        room = ChatRoom('test_room')
        room.add_member('user1')
        
        # Should not raise exception
        room.remove_member('user2')
        self.assertEqual(len(room.members), 1)
    
    def test_message_history(self):
        """Test message history tracking"""
        room = ChatRoom('test_room')
        room.add_message('user1', 'Hello')
        room.add_message('user2', 'Hi there')
        
        self.assertEqual(len(room.message_history), 2)
        self.assertEqual(room.message_history[0]['username'], 'user1')
        self.assertEqual(room.message_history[0]['message'], 'Hello')
        self.assertIn('timestamp', room.message_history[0])
    
    def test_message_history_limit(self):
        """Test message history is limited to 100 messages"""
        room = ChatRoom('test_room')
        
        # Add 150 messages
        for i in range(150):
            room.add_message('user', f'Message {i}')
        
        self.assertEqual(len(room.message_history), 100)
        # First message should be message 50 (0-49 were removed)
        self.assertEqual(room.message_history[0]['message'], 'Message 50')


class TestSecureChatServer(unittest.TestCase):
    """Test chat server functionality"""
    
    def test_server_initialization(self):
        """Test server object creation"""
        server = SecureChatServer('127.0.0.1', 8888)
        
        self.assertEqual(server.host, '127.0.0.1')
        self.assertEqual(server.port, 8888)
        self.assertIn('general', server.rooms)
        self.assertFalse(server.running)
    
    def test_username_validation_too_short(self):
        """Test username validation for short names"""
        server = SecureChatServer()
        
        valid, msg = server.validate_username('ab')
        self.assertFalse(valid)
        self.assertIn('3 characters', msg)
    
    def test_username_validation_too_long(self):
        """Test username validation for long names"""
        server = SecureChatServer()
        
        valid, msg = server.validate_username('a' * 21)
        self.assertFalse(valid)
        self.assertIn('20 characters', msg)
    
    def test_username_validation_invalid_chars(self):
        """Test username validation for invalid characters"""
        server = SecureChatServer()
        
        valid, msg = server.validate_username('user@123')
        self.assertFalse(valid)
        self.assertIn('letters, numbers', msg.lower())
    
    def test_username_validation_valid(self):
        """Test username validation for valid names"""
        server = SecureChatServer()
        
        valid, msg = server.validate_username('valid_user123')
        self.assertTrue(valid)
    
    def test_username_already_taken(self):
        """Test username validation for duplicate names"""
        server = SecureChatServer()
        mock_socket = MagicMock()
        server.username_map['existinguser'] = mock_socket
        
        valid, msg = server.validate_username('existinguser')
        self.assertFalse(valid)
        self.assertIn('already taken', msg.lower())
    
    def test_username_case_insensitive(self):
        """Test username is case-insensitive"""
        server = SecureChatServer()
        mock_socket = MagicMock()
        server.username_map['ExistingUser'] = mock_socket
        
        valid, msg = server.validate_username('existinguser')
        self.assertFalse(valid)
    
    def test_message_serialization(self):
        """Test message serialization"""
        server = SecureChatServer()
        mock_socket = MagicMock()
        
        test_message = {'type': 'system', 'message': 'Test'}
        server.send_message(mock_socket, test_message)
        
        self.assertTrue(mock_socket.sendall.called)
        
        # Verify format
        call_args = mock_socket.sendall.call_args[0][0]
        self.assertIsInstance(call_args, bytes)
        self.assertEqual(len(call_args), 4 + len(json.dumps(test_message)))
    
    def test_room_creation(self):
        """Test creating new chat rooms"""
        server = SecureChatServer()
        
        # Initially only general room exists
        self.assertEqual(len(server.rooms), 1)
        
        # Add new room
        server.rooms['lobby'] = ChatRoom('lobby')
        
        self.assertIn('lobby', server.rooms)
        self.assertEqual(len(server.rooms), 2)
    
    def test_get_user_room(self):
        """Test getting user's current room"""
        server = SecureChatServer()
        mock_socket = MagicMock()
        
        server.clients[mock_socket] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        
        room = server.get_user_room('testuser')
        self.assertEqual(room, 'general')
    
    def test_get_user_room_nonexistent(self):
        """Test getting room for nonexistent user"""
        server = SecureChatServer()
        
        room = server.get_user_room('nonexistent')
        self.assertIsNone(room)
    
    def test_get_user_address(self):
        """Test getting user's IP address"""
        server = SecureChatServer()
        mock_socket = MagicMock()
        
        server.clients[mock_socket] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('192.168.1.100', 12345)
        }
        
        address = server.get_user_address('testuser')
        self.assertEqual(address, ('192.168.1.100', 12345))
    
    def test_broadcast_message(self):
        """Test broadcasting message to room"""
        server = SecureChatServer()
        
        # Create mock clients
        mock1 = MagicMock()
        mock2 = MagicMock()
        mock3 = MagicMock()
        
        server.clients[mock1] = {'username': 'user1', 'room': 'general', 'address': ('127.0.0.1', 1)}
        server.clients[mock2] = {'username': 'user2', 'room': 'general', 'address': ('127.0.0.1', 2)}
        server.clients[mock3] = {'username': 'user3', 'room': 'lobby', 'address': ('127.0.0.1', 3)}
        
        test_msg = {'type': 'message', 'content': 'Hello'}
        server.broadcast_message(test_msg, 'general')
        
        # Both users in general should receive
        self.assertTrue(mock1.sendall.called)
        self.assertTrue(mock2.sendall.called)
        # User in lobby should not receive
        self.assertFalse(mock3.sendall.called)
    
    def test_broadcast_exclude_sender(self):
        """Test broadcasting excludes sender"""
        server = SecureChatServer()
        
        mock1 = MagicMock()
        mock2 = MagicMock()
        
        server.clients[mock1] = {'username': 'user1', 'room': 'general', 'address': ('127.0.0.1', 1)}
        server.clients[mock2] = {'username': 'user2', 'room': 'general', 'address': ('127.0.0.1', 2)}
        
        test_msg = {'type': 'message', 'content': 'Hello'}
        server.broadcast_message(test_msg, 'general', exclude_client=mock1)
        
        # Sender should not receive
        self.assertFalse(mock1.sendall.called)
        # Other user should receive
        self.assertTrue(mock2.sendall.called)


class TestServerMessageProcessing(unittest.TestCase):
    """Test server message processing logic"""
    
    def setUp(self):
        """Set up test environment"""
        self.server = SecureChatServer()
        self.mock_client = MagicMock()
        
        self.server.clients[self.mock_client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        self.server.username_map['testuser'] = self.mock_client
        self.server.rooms['general'].add_member('testuser')
    
    def test_process_chat_message(self):
        """Test processing regular chat messages"""
        message = {
            'type': 'message',
            'content': 'Hello everyone'
        }
        
        self.server.process_message(self.mock_client, message)
        
        # Verify message added to room history
        self.assertEqual(len(self.server.rooms['general'].message_history), 1)
        self.assertEqual(self.server.rooms['general'].message_history[0]['message'], 'Hello everyone')
    
    def test_process_empty_message(self):
        """Test processing empty message is ignored"""
        message = {
            'type': 'message',
            'content': ''
        }
        
        self.server.process_message(self.mock_client, message)
        
        # Empty message should not be added
        self.assertEqual(len(self.server.rooms['general'].message_history), 0)
    
    def test_process_list_users(self):
        """Test processing list users request"""
        message = {'type': 'list_users'}
        
        self.server.process_message(self.mock_client, message)
        
        # Verify response was sent
        self.assertTrue(self.mock_client.sendall.called)
    
    def test_process_create_room(self):
        """Test processing room creation"""
        message = {
            'type': 'create_room',
            'room_name': 'newroom'
        }
        
        self.server.process_message(self.mock_client, message)
        
        self.assertIn('newroom', self.server.rooms)
    
    def test_process_create_duplicate_room(self):
        """Test creating room that already exists"""
        message = {
            'type': 'create_room',
            'room_name': 'general'
        }
        
        initial_count = len(self.server.rooms)
        self.server.process_message(self.mock_client, message)
        
        # Should not create duplicate
        self.assertEqual(len(self.server.rooms), initial_count)
    
    def test_process_join_room(self):
        """Test processing room join"""
        # Create second room
        self.server.rooms['lobby'] = ChatRoom('lobby')
        
        message = {
            'type': 'join_room',
            'room_name': 'lobby'
        }
        
        self.server.process_message(self.mock_client, message)
        
        # Verify user moved to new room
        self.assertEqual(self.server.clients[self.mock_client]['room'], 'lobby')
        self.assertIn('testuser', self.server.rooms['lobby'].members)
        self.assertNotIn('testuser', self.server.rooms['general'].members)
    
    def test_process_join_nonexistent_room(self):
        """Test joining room that doesn't exist"""
        message = {
            'type': 'join_room',
            'room_name': 'nonexistent'
        }
        
        self.server.process_message(self.mock_client, message)
        
        # User should stay in current room
        self.assertEqual(self.server.clients[self.mock_client]['room'], 'general')
    
    def test_process_private_message(self):
        """Test processing private messages"""
        # Add second user
        mock_target = MagicMock()
        self.server.clients[mock_target] = {
            'username': 'targetuser',
            'room': 'general',
            'address': ('127.0.0.1', 12346)
        }
        self.server.username_map['targetuser'] = mock_target
        
        message = {
            'type': 'private_message',
            'target': 'targetuser',
            'content': 'Secret message'
        }
        
        self.server.process_message(self.mock_client, message)
        
        # Verify message sent to target
        self.assertTrue(mock_target.sendall.called)
    
    def test_process_private_message_to_nonexistent_user(self):
        """Test sending PM to user that doesn't exist"""
        message = {
            'type': 'private_message',
            'target': 'nonexistent',
            'content': 'Secret message'
        }
        
        self.server.process_message(self.mock_client, message)
        
        # Should receive error notification
        self.assertTrue(self.mock_client.sendall.called)


if __name__ == '__main__':
    unittest.main()
