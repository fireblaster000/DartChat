"""
DartChat Test Suite
Comprehensive testing for the secure chat application
"""
