"""
Edge Case Tests for DartChat Application
Tests error handling, boundary conditions, and unusual scenarios
"""
import unittest
import json
import socket
from unittest.mock import Mock, patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from chat_server import SecureChatServer, ChatRoom


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and error handling"""
    
    def test_empty_username(self):
        """Test handling of empty username"""
        server = SecureChatServer()
        valid, msg = server.validate_username('')
        
        self.assertFalse(valid)
    
    def test_empty_message_not_broadcast(self):
        """Test empty messages are not broadcast"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        
        # Send empty message
        server.process_message(client, {
            'type': 'message',
            'content': ''
        })
        
        # Should not be added to history
        self.assertEqual(len(server.rooms['general'].message_history), 0)
    
    def test_whitespace_only_message(self):
        """Test whitespace-only messages are not broadcast"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        
        # Send whitespace message
        server.process_message(client, {
            'type': 'message',
            'content': '   '
        })
        
        self.assertEqual(len(server.rooms['general'].message_history), 0)
    
    def test_join_nonexistent_room(self):
        """Test joining room that doesn't exist"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.rooms['general'].add_member('testuser')
        
        initial_room = server.clients[client]['room']
        
        # Try to join non-existent room
        server.process_message(client, {
            'type': 'join_room',
            'room_name': 'nonexistent'
        })
        
        # Should stay in current room
        self.assertEqual(server.clients[client]['room'], initial_room)
    
    def test_pm_to_nonexistent_user(self):
        """Test private message to user that doesn't exist"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.username_map['testuser'] = client
        
        # Send PM to non-existent user
        server.process_message(client, {
            'type': 'private_message',
            'target': 'ghostuser',
            'content': 'Hello'
        })
        
        # Should receive error message
        self.assertTrue(client.sendall.called)
    
    def test_duplicate_room_creation(self):
        """Test creating room that already exists"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        
        # Try to create 'general' again
        initial_room_count = len(server.rooms)
        
        server.process_message(client, {
            'type': 'create_room',
            'room_name': 'general'
        })
        
        # Room count should not increase
        self.assertEqual(len(server.rooms), initial_room_count)
    
    def test_file_send_to_self(self):
        """Test sending file to yourself"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.username_map['testuser'] = client
        
        # Try to send file to self
        server.process_message(client, {
            'type': 'file_send',
            'targets': ['testuser'],
            'filename': 'test.txt',
            'filesize': 100,
            'data': 'base64data'
        })
        
        # Should not create pending file
        self.assertEqual(len(server.pending_files), 0)
    
    def test_file_send_to_wrong_room(self):
        """Test sending file to user in different room"""
        server = SecureChatServer()
        
        sender = MagicMock()
        receiver = MagicMock()
        
        server.clients[sender] = {
            'username': 'sender',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[receiver] = {
            'username': 'receiver',
            'room': 'vip',
            'address': ('127.0.0.1', 12346)
        }
        server.username_map['sender'] = sender
        server.username_map['receiver'] = receiver
        server.rooms['vip'] = ChatRoom('vip')
        
        # Try to send file to user in different room
        server.process_message(sender, {
            'type': 'file_send',
            'targets': ['receiver'],
            'filename': 'test.txt',
            'filesize': 100,
            'data': 'base64data'
        })
        
        # Should not create pending file
        self.assertEqual(len(server.pending_files), 0)
    
    def test_accept_nonexistent_file(self):
        """Test accepting file offer that doesn't exist"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        
        # Try to accept non-existent file
        server.process_message(client, {
            'type': 'file_accept',
            'file_id': 'nonexistent123'
        })
        
        # Should receive error message
        self.assertTrue(client.sendall.called)
    
    def test_malformed_json_message(self):
        """Test handling of malformed JSON"""
        # Test JSON parsing
        malformed = b'{"type": "message", "content": '
        
        with self.assertRaises(json.JSONDecodeError):
            json.loads(malformed.decode('utf-8'))
    
    def test_disconnect_removes_pending_calls(self):
        """Test that disconnecting removes pending voice calls"""
        server = SecureChatServer()
        client = MagicMock()
        
        server.clients[client] = {
            'username': 'testuser',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.username_map['testuser'] = client
        server.active_calls['testuser'] = {'peer': 'other'}
        
        # Disconnect
        server.disconnect_client(client, 'testuser')
        
        # Active call should be removed
        self.assertNotIn('testuser', server.active_calls)
    
    def test_call_user_in_different_room(self):
        """Test calling user in different room fails"""
        server = SecureChatServer()
        
        caller = MagicMock()
        callee = MagicMock()
        
        server.clients[caller] = {
            'username': 'caller',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[callee] = {
            'username': 'callee',
            'room': 'vip',
            'address': ('127.0.0.1', 12346)
        }
        server.username_map['caller'] = caller
        server.username_map['callee'] = callee
        server.rooms['vip'] = ChatRoom('vip')
        
        # Try to call user in different room
        server.process_message(caller, {
            'type': 'call_request',
            'target': 'callee',
            'voice_port': 5000
        })
        
        # Should receive error
        self.assertTrue(caller.sendall.called)
    
    def test_username_with_spaces(self):
        """Test username with spaces is invalid"""
        server = SecureChatServer()
        valid, msg = server.validate_username('user name')
        
        self.assertFalse(valid)


class TestConcurrencyEdgeCases(unittest.TestCase):
    """Test concurrent access edge cases"""
    
    def test_simultaneous_room_creation(self):
        """Test multiple clients creating same room simultaneously"""
        server = SecureChatServer()
        
        client1 = MagicMock()
        client2 = MagicMock()
        
        server.clients[client1] = {
            'username': 'user1',
            'room': 'general',
            'address': ('127.0.0.1', 12345)
        }
        server.clients[client2] = {
            'username': 'user2',
            'room': 'general',
            'address': ('127.0.0.1', 12346)
        }
        
        # Both try to create same room
        server.process_message(client1, {
            'type': 'create_room',
            'room_name': 'newroom'
        })
        
        server.process_message(client2, {
            'type': 'create_room',
            'room_name': 'newroom'
        })
        
        # Should only have one instance
        self.assertEqual(len([r for r in server.rooms if r == 'newroom']), 1)
    
    def test_message_order_preservation(self):
        """Test that message order is preserved"""
        room = ChatRoom('test')
        
        # Add messages in order
        for i in range(10):
            room.add_message('user', f'Message {i}')
        
        # Verify order
        for i, msg in enumerate(room.message_history):
            self.assertEqual(msg['message'], f'Message {i}')


if __name__ == '__main__':
    unittest.main()
