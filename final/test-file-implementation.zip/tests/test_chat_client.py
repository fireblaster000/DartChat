"""
Unit Tests for Chat Client
Tests client initialization, message handling, and command processing
"""
import unittest
import socket
import ssl
import json
import os
import tempfile
import shutil
from unittest.mock import Mock, patch, MagicMock, call
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'src'))

from chat_client import SecureChatClient


class TestSecureChatClient(unittest.TestCase):
    """Test chat client functionality"""
    
    def setUp(self):
        """Set up test environment"""
        self.test_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        """Clean up test environment"""
        shutil.rmtree(self.test_dir)
    
    def test_client_initialization(self):
        """Test client object initialization"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient('localhost', 9999)
        
        self.assertEqual(client.host, 'localhost')
        self.assertEqual(client.port, 9999)
        self.assertIsNone(client.username)
        self.assertEqual(client.current_room, 'general')
        self.assertFalse(client.running)
        self.assertFalse(client.connected)
    
    def test_ssl_context_creation(self):
        """Test SSL context is created correctly"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        context = client.create_ssl_context()
        
        self.assertIsInstance(context, ssl.SSLContext)
        self.assertEqual(context.verify_mode, ssl.CERT_NONE)
        self.assertFalse(context.check_hostname)
    
    def test_message_serialization(self):
        """Test JSON message serialization"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        mock_socket = MagicMock()
        client.socket = mock_socket
        
        test_message = {'type': 'message', 'content': 'Hello'}
        client.send_message(test_message)
        
        # Verify sendall was called
        self.assertTrue(mock_socket.sendall.called)
        
        # Check the data format
        call_args = mock_socket.sendall.call_args[0][0]
        self.assertIsInstance(call_args, bytes)
    
    def test_command_parsing_quit(self):
        """Test /quit command handling"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        result = client.handle_command("/quit")
        
        self.assertFalse(result)
    
    def test_command_parsing_help(self):
        """Test /help command handling"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        mock_socket = MagicMock()
        client.socket = mock_socket
        client.connected = True
        
        result = client.handle_command("/help")
        
        self.assertTrue(result)
    
    def test_private_message_command(self):
        """Test /pm command parsing"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        mock_socket = MagicMock()
        client.socket = mock_socket
        client.connected = True
        
        client.handle_command("/pm testuser Hello there")
        
        # Verify message was sent
        self.assertTrue(mock_socket.sendall.called)
    
    def test_file_size_formatting(self):
        """Test human-readable file size formatting"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        
        self.assertEqual(client.format_size(500), "500.0B")
        self.assertEqual(client.format_size(1024), "1.0KB")
        self.assertEqual(client.format_size(1024 * 1024), "1.0MB")
        self.assertEqual(client.format_size(1024 * 1024 * 1024), "1.0GB")
    
    def test_downloads_directory_created(self):
        """Test downloads directory is created"""
        from chat_client import SecureChatClient
        
        original_cwd = os.getcwd()
        os.chdir(self.test_dir)
        
        try:
            client = SecureChatClient()
            self.assertTrue(os.path.exists(client.download_dir))
        finally:
            os.chdir(original_cwd)
    
    def test_process_auth_success(self):
        """Test authentication success message processing"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        client.socket = MagicMock()
        
        auth_msg = {
            'type': 'auth_success',
            'username': 'testuser',
            'room': 'general'
        }
        
        client.process_message(auth_msg)
        
        self.assertEqual(client.username, 'testuser')
        self.assertEqual(client.current_room, 'general')
        self.assertTrue(client.connected)
    
    def test_process_room_changed(self):
        """Test room change message processing"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        client.socket = MagicMock()
        client.current_room = 'general'
        
        room_msg = {
            'type': 'room_changed',
            'room': 'lobby',
            'message': 'Joined room lobby'
        }
        
        client.process_message(room_msg)
        
        self.assertEqual(client.current_room, 'lobby')
    
    def test_file_offer_tracking(self):
        """Test file offer is displayed"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        client.socket = MagicMock()
        client.connected = True
        
        file_msg = {
            'type': 'file_offer',
            'from': 'sender',
            'filename': 'test.txt',
            'filesize': 1024,
            'file_id': 'abc123',
            'broadcast': False
        }
        
        # Should not raise exception
        try:
            client.process_message(file_msg)
        except Exception as e:
            self.fail(f"process_message raised exception: {e}")


class TestClientFileOperations(unittest.TestCase):
    """Test client file transfer operations"""
    
    def setUp(self):
        """Set up test environment"""
        self.test_dir = tempfile.mkdtemp()
        self.original_cwd = os.getcwd()
        os.chdir(self.test_dir)
        
        # Create a test file
        self.test_file = 'test.txt'
        with open(self.test_file, 'w') as f:
            f.write('Test content')
    
    def tearDown(self):
        """Clean up test environment"""
        os.chdir(self.original_cwd)
        shutil.rmtree(self.test_dir)
    
    @patch('chat_client.base64.b64encode')
    def test_send_file_encoding(self, mock_b64):
        """Test file is base64 encoded before sending"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        client.socket = MagicMock()
        client.connected = True
        client.username = 'testuser'
        
        mock_b64.return_value.decode.return_value = 'encodeddata'
        
        client.send_file(['targetuser'], self.test_file)
        
        # Verify base64 encoding was called
        self.assertTrue(mock_b64.called)
    
    def test_send_file_to_self_rejected(self):
        """Test cannot send file to yourself"""
        from chat_client import SecureChatClient
        
        client = SecureChatClient()
        client.socket = MagicMock()
        client.connected = True
        client.username = 'testuser'
        
        # Should not send
        client.send_file(['testuser'], self.test_file)
        
        # Verify no message sent
        self.assertFalse(client.socket.sendall.called)
    
    def test_file_too_large_rejected(self):
        """Test large files are rejected"""
        from chat_client import SecureChatClient
        
        # Create large file
        large_file = 'large.bin'
        with open(large_file, 'wb') as f:
            f.write(b'\x00' * (11 * 1024 * 1024))  # 11MB
        
        client = SecureChatClient()
        client.socket = MagicMock()
        client.connected = True
        client.username = 'testuser'
        
        client.send_file(['targetuser'], large_file)
        
        # Verify no message sent
        self.assertFalse(client.socket.sendall.called)


if __name__ == '__main__':
    unittest.main()
