# DartChat Test Suite - Comprehensive Guide

This guide provides detailed information about the test suite implementation, test coverage, and best practices for maintaining and extending the tests.

## Overview

The DartChat test suite is designed to validate all core functionalities of the secure chat application through:
- **Unit Tests**: Individual component testing
- **Integration Tests**: Component interaction testing
- **End-to-End Tests**: Complete user workflow simulation
- **Edge Case Tests**: Error handling and boundary conditions

## Test Architecture

### Test Organization

\`\`\`
tests/
├── __init__.py                  # Test package initialization
├── test_generate_certificates.py # Certificate generation tests
├── test_chat_server.py           # Server logic tests
├── test_chat_client.py           # Client functionality tests
├── test_voice_call.py            # Voice call tests
├── test_integration.py           # Integration tests
├── test_edge_cases.py            # Edge case and error tests
├── run_all_tests.py              # Test runner
├── README.md                     # Quick start guide
└── TEST_GUIDE.md                 # This file
\`\`\`

## Detailed Test Coverage

### 1. Certificate Generation Tests (`test_generate_certificates.py`)

**Purpose**: Validate TLS certificate creation and security configuration.

**Key Tests**:
- Certificate directory creation
- Private key generation (RSA 2048-bit)
- Certificate file generation
- Validity period (365 days)
- Subject fields (CN, O, C)
- Subject Alternative Name (SAN) extension
- Key size verification
- Multiple generation handling

**Example**:
\`\`\`python
def test_certificate_validity_period(self):
    generate_certificates()
    with open('certs/server.crt', 'rb') as f:
        cert = x509.load_pem_x509_certificate(f.read(), default_backend())
    validity_period = cert.not_valid_after - cert.not_valid_before
    self.assertAlmostEqual(validity_period.days, 365, delta=1)
\`\`\`

### 2. Chat Server Tests (`test_chat_server.py`)

**Purpose**: Validate server-side logic, room management, and message routing.

**Key Test Classes**:

#### TestChatRoom
- Room initialization
- Member addition/removal
- Duplicate member handling
- Message history tracking
- Message history limits (100 messages)

#### TestSecureChatServer
- Server initialization
- Username validation (length, characters, uniqueness, case-insensitivity)
- Message serialization
- Room creation
- User location tracking
- Broadcast message distribution
- Sender exclusion in broadcasts

#### TestServerMessageProcessing
- Chat message processing
- Empty message filtering
- User list requests
- Room creation/joining
- Private messaging
- Cross-room message restrictions

### 3. Chat Client Tests (`test_chat_client.py`)

**Purpose**: Validate client-side functionality, command parsing, and file handling.

**Key Test Classes**:

#### TestSecureChatClient
- Client initialization
- SSL context creation
- Message serialization
- Command parsing (/quit, /help, /pm)
- File size formatting
- Downloads directory creation
- Authentication success handling
- Room change processing
- File offer tracking

#### TestClientFileOperations
- File base64 encoding
- Self-send rejection
- Large file rejection (>10MB)
- File path validation

### 4. Voice Call Tests (`test_voice_call.py`)

**Purpose**: Validate voice call functionality and audio streaming.

**Key Tests**:
- VoiceCall initialization
- Call start/stop lifecycle
- Mute/unmute toggle
- Active call prevention (can't restart active call)
- Audio packet structure (sequence number + data)
- PyAudio stream management
- Socket cleanup

**Audio Tester Tests**:
- AudioTester initialization
- Device listing
- Audio configuration validation

### 5. Integration Tests (`test_integration.py`)

**Purpose**: Test complete workflows and component interactions.

**Key Test Classes**:

#### TestClientServerIntegration
- Connection handshake flow
- Message serialization/deserialization
- Complete room workflow (create → join → leave)
- Complete file transfer workflow (send → offer → accept → transfer)
- Broadcast message distribution

#### TestVoiceCallIntegration
- Call request workflow
- Complete call lifecycle (start → mute → unmute → end)

#### TestEndToEndScenarios
- User session (join → chat → leave)
- Multi-user multi-room scenario
- Private messaging between users

### 6. Edge Case Tests (`test_edge_cases.py`)

**Purpose**: Validate error handling and boundary conditions.

**Key Test Classes**:

#### TestEdgeCases
- Empty username validation
- Empty/whitespace message filtering
- Joining non-existent rooms
- Private messages to non-existent users
- Duplicate room creation prevention
- File send to self prevention
- Cross-room file transfer prevention
- Non-existent file acceptance
- Malformed JSON handling
- Call cleanup on disconnect
- Cross-room call prevention
- Username with invalid characters

#### TestConcurrencyEdgeCases
- Simultaneous room creation
- Message order preservation

## Test Execution Strategies

### Quick Test Run
\`\`\`bash
# Run all tests
python tests/run_all_tests.py
\`\`\`

### Targeted Testing
\`\`\`bash
# Test specific functionality
python -m unittest tests.test_chat_server.TestChatRoom

# Test specific method
python -m unittest tests.test_chat_server.TestChatRoom.test_add_member
\`\`\`

### Development Workflow
\`\`\`bash
# Watch mode (using external tool like pytest-watch)
# Install: pip install pytest-watch
ptw tests/
\`\`\`

### Coverage Analysis
\`\`\`bash
# Install coverage
pip install coverage

# Run with coverage
coverage run -m unittest discover tests/
coverage report
coverage html  # Generate HTML report
\`\`\`

## Mocking Strategy

The test suite uses extensive mocking to isolate components and avoid external dependencies:

### Network Mocking
\`\`\`python
@patch('chat_server.ssl.SSLContext')
@patch('chat_client.ssl.SSLContext')
def test_connection_handshake(self, mock_client_ssl, mock_server_ssl):
    # Test without actual SSL connections
\`\`\`

### Audio Mocking
\`\`\`python
@patch('voice_call.pyaudio.PyAudio')
def test_voice_call_start(self, mock_pyaudio):
    mock_audio = MagicMock()
    mock_pyaudio.return_value = mock_audio
    # Test without actual audio hardware
\`\`\`

### Socket Mocking
\`\`\`python
mock_socket = MagicMock()
client.socket = mock_socket
client.send_message({'type': 'message', 'content': 'Hello'})
self.assertTrue(mock_socket.sendall.called)
\`\`\`

## Best Practices

### Writing New Tests

1. **Follow Naming Conventions**
   - Test files: `test_*.py`
   - Test classes: `Test<Component>`
   - Test methods: `test_<functionality>`

2. **Use Descriptive Names**
   \`\`\`python
   # Good
   def test_username_validation_rejects_short_names(self):
   
   # Bad
   def test_username(self):
   \`\`\`

3. **Structure Tests with AAA Pattern**
   \`\`\`python
   def test_example(self):
       # Arrange
       server = SecureChatServer()
       client = MagicMock()
       
       # Act
       result = server.validate_username('test')
       
       # Assert
       self.assertTrue(result[0])
   \`\`\`

4. **Test One Thing Per Test**
   - Each test should validate a single behavior
   - Makes failures easier to diagnose
   - Improves test maintainability

5. **Use Setup and Teardown**
   \`\`\`python
   def setUp(self):
       self.test_dir = tempfile.mkdtemp()
       
   def tearDown(self):
       shutil.rmtree(self.test_dir)
   \`\`\`

### Testing Async/Threaded Code

\`\`\`python
def test_threaded_operation(self):
    # Start operation
    call.start()
    
    # Give threads time to start
    time.sleep(0.1)
    
    # Test state
    self.assertTrue(call.is_active)
    
    # Cleanup
    call.stop()
\`\`\`

## Continuous Integration

### GitHub Actions Example
\`\`\`yaml
name: Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: 3.9
      - name: Install dependencies
        run: |
          pip install cryptography pyaudio
      - name: Run tests
        run: python tests/run_all_tests.py
\`\`\`

## Troubleshooting

### Common Issues

**Issue**: PyAudio import errors in tests
\`\`\`bash
# Solution: Tests mock PyAudio, no actual installation needed
# If you see import errors, ensure mocking is properly configured
\`\`\`

**Issue**: SSL certificate tests fail
\`\`\`bash
# Solution: Ensure cryptography library is installed
pip install cryptography
\`\`\`

**Issue**: Tests hang or timeout
\`\`\`bash
# Solution: Check for infinite loops or unjoined threads
# Add timeout to problematic tests
@timeout_decorator.timeout(5)
def test_long_operation(self):
    pass
\`\`\`

## Future Test Enhancements

### Planned Additions
- [ ] Performance/load testing
- [ ] Memory leak detection
- [ ] Network latency simulation
- [ ] Stress testing for concurrent users
- [ ] Security penetration tests
- [ ] UI/GUI automated tests (for chat_gui_client)

### Testing Best Practices to Implement
- Property-based testing with hypothesis
- Mutation testing with mutmut
- Contract testing for API boundaries

## Contributing Tests

When adding new features to DartChat:

1. **Write tests first** (TDD approach)
2. **Cover happy path** (normal operation)
3. **Cover error paths** (exceptions, invalid inputs)
4. **Add integration tests** (component interactions)
5. **Update documentation** (this guide and README)

### Test Review Checklist
- [ ] Tests are properly named and organized
- [ ] All assertions have clear failure messages
- [ ] Mocks are used appropriately
- [ ] Tests are independent (no shared state)
- [ ] Edge cases are covered
- [ ] Documentation is updated

## Test Metrics

Current test suite metrics:
- **Total Test Files**: 6
- **Total Test Classes**: 15+
- **Total Test Methods**: 80+
- **Estimated Coverage**: ~85% of core functionality
- **Average Test Execution Time**: <5 seconds

## Contact

For questions about the test suite, please refer to:
- Main README.md for project overview
- Code comments for specific test explanations
- Git history for test evolution and rationale
